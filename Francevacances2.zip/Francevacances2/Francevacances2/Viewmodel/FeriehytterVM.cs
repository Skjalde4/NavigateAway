﻿using Francevacances2.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Francevacances2.Viewmodel
{
   class FeriehytterVM : INotifyPropertyChanged
    {
        private ImageList imageListSmall = new ImageList();

        #region PropertyChangeSupport
        public event PropertyChangedEventHandler PropertyChanged;

        // Create the OnPropertyChanged method to raise the event
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            { handler(this, new PropertyChangedEventArgs(name)); }
        }
        #endregion

        //  ObservableCollection
        
        private ObservableCollection<Feriehytte> _feriehytteliste;
        public ObservableCollection<Feriehytte> Feriehytteliste { get; set; }
        public Uri uri { get; set; }
        public FeriehytterVM()
        {
            uri = new Uri("ms-appx:///Assets/franskhus1.jpg", UriKind.Absolute);
            _feriehytteliste = Feriehytteliste;
            Feriehytteliste = new ObservableCollection<Feriehytte>();

            Feriehytte feriehytte1 = new Feriehytte(1, "Villa", "datamatikervej2", 5000.0, 200.0, new Uri("ms-appx:///Assets/franskhus1.jpg", UriKind.Absolute));
            Feriehytteliste.Add(feriehytte1);

            Feriehytte feriehytte2 = new Feriehytte(2, "Lejlighed", "Datamatikervej3", 2000.0, 100.0, new Uri("ms-appx:///Assets/FWhus.jpg", UriKind.Absolute));
            Feriehytteliste.Add(feriehytte2);

            Feriehytte feriehytte3 = new Feriehytte(3, "Sommerhus", "datamatikervej4", 1000.0, 50.0, new Uri("ms-appx:///Assets/FWhus2.png", UriKind.Absolute));
            Feriehytteliste.Add(feriehytte3);
        }
    }
}
