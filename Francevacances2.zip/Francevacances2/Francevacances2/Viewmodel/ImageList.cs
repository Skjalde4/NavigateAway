﻿namespace Francevacances2.Viewmodel
{
    internal class ImageList
    {
    }
}