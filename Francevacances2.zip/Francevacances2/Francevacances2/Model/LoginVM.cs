﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Francevacances2.Model
{
    class LoginVM : INotifyPropertyChanged
    {
       

     //  private string _username;
     //  private string _password;

        #region PropertyChangeSupport
        public event PropertyChangedEventHandler PropertyChanged;

        // Create the OnPropertyChanged method to raise the event
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            { handler(this, new PropertyChangedEventArgs(name)); }
        } 
        #endregion
         
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
