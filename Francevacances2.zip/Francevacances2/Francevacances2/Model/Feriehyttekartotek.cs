﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Francevacances2.Model
{
    class Feriehyttekartotek
    { 

    //Dictionary<int, Feriehytter> Hyttekartotek = new Dictionary<int, Feriehytter>();

    //public void Visferiehytter(Feriehytter feriehytter, int i)
    //{
    //    Hyttekartotek.Add(i, feriehytter);
    //}
    //public void Udskriv()
    //{
    //    foreach (KeyValuePair<int, Feriehytter> keyValue in Hyttekartotek)
    //    {
    //       //Console.WriteLine(keyValue.Value);
    //    }
    //}
    //public void Remove(Feriehytter feriehytter)
    //{
    //    Hyttekartotek.Remove(feriehytter.Id);
    //}
  }
}
