﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Francevacances2.Model
{
    class Feriehytte
    {
        public Feriehytte()
        {

        }
        private int _Id;
        private string _Type;
        private string _Adresse;
        private double _Pris;
        private double _Storrelse;
        private Uri _myuri;

        public Uri myuri { get => _myuri; set => _myuri = value; }



        public Feriehytte(int Id, string Type, string Adresse, double Pris, double Storrelse, Uri Myuri)
        {
            _Id = Id;
            _Type = Type;
            _Adresse = Adresse;
            _Pris = Pris;
            _Storrelse = Storrelse;
            _myuri = Myuri;

        }
        public int Id
        {
            get { return _Id; }
        }
        public string Type
        {
            get { return _Type; }
        }
        public string Adresse
        {
            get { return _Adresse; }
        }
        public double Pris
        {
            get { return _Pris; }
        }
        public double Storrelse
        {
            get { return _Storrelse; }
        }
        public override string ToString()
        {
            return $"{nameof(Type)}: {Type}, {nameof(Adresse)}: {Adresse}, {nameof(Pris)}: {Pris}, {nameof(Storrelse)}: {Storrelse}";
        }
    }
}

